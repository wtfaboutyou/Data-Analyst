-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 10:12 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makul_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_a`
--

CREATE TABLE `tabel_a` (
  `id_transaksi` int(11) NOT NULL,
  `kode_transaksi` varchar(15) NOT NULL,
  `kode_pelanggan` varchar(15) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_produk` varchar(15) NOT NULL,
  `nama_produk` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_a`
--

INSERT INTO `tabel_a` (`id_transaksi`, `kode_transaksi`, `kode_pelanggan`, `no_urut`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(1, 'tr-001', 'polibest07', 1, 'prod-01', 'Kotak Pensil', 5, 62500),
(2, 'tr-001', 'polibest07', 2, 'prod-02', 'Flashdisk 32 GB', 1, 100000),
(3, 'tr-001', 'polibest07', 3, 'prod-09', 'Buku Planner Agenda', 3, 92000),
(4, 'tr-001', 'polibest07', 4, 'prod-04', 'Flashdisk 32 GB', 3, 40000),
(5, 'tr-002', 'polibest01', 1, 'prod-03', 'Gift Voucher 100rb', 2, 100000),
(6, 'tr-002', 'polibest01', 2, 'prod-10', 'Sticky Note 500 Sheets', 5, 55000),
(7, 'tr-002', 'polibest01', 3, 'prod-07', 'Tas Travel Organizer', 1, 48000),
(8, 'tr-003', 'polibest03', 1, 'prod-02', 'Flashdisk 64 GB', 2, 55000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_a`
--
ALTER TABLE `tabel_a`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_a`
--
ALTER TABLE `tabel_a`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
