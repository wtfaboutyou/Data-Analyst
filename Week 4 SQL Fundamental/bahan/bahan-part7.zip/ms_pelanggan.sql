-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 10:12 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makul_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ms_pelanggan`
--

CREATE TABLE `ms_pelanggan` (
  `no_urut` int(11) NOT NULL,
  `kode_pelanggan` varchar(20) NOT NULL,
  `nama_customer` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ms_pelanggan`
--

INSERT INTO `ms_pelanggan` (`no_urut`, `kode_pelanggan`, `nama_customer`, `alamat`) VALUES
(1, 'polibest01', 'Evi Novianti', 'Jl. Argoluwih No. 15, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(2, 'polibest02', 'Heidi Goh', 'Jl. Argoluwih No. 15, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(3, 'polibest03', 'Unang Handoko', 'Jl. Argoluwih No. 16, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(4, 'polibest04', 'Jokolono Sukarman', 'Jl. Argoluwih No. 17, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(5, 'polibest05', 'Tomy Sinaga', 'Jl. Argoluwih No. 18, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(6, 'polibest06', 'Irwan Setianto', 'Perum Villa Asri No. 15, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(7, 'polibest07', 'Agus Cahyono', 'Perum Villa Asri No. 16, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(8, 'polibest08', 'Maria Sirait', 'Perum Pondok Indah No. 17, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(9, 'polibest09', 'Ita Nugraha', 'Perum Pondok Indah No. 16, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(10, 'polibest10', 'Joko Wardoyo', 'Perum Grogol Indah No. 16, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(11, 'polibest11', 'Unang Handoko', 'Jl. Argoluwih No. 16, Kel.Ledok, Kec.Argomulyo, Kota Salatiga'),
(12, 'polibest12', 'Tomy Sinaga', 'Jl. Argoluwih No. 18, Kel.Ledok, Kec.Argomulyo, Kota Salatiga');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ms_pelanggan`
--
ALTER TABLE `ms_pelanggan`
  ADD PRIMARY KEY (`no_urut`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
