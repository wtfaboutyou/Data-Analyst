-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 10:12 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makul_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_b`
--

CREATE TABLE `tabel_b` (
  `id_transaksi` int(11) NOT NULL,
  `kode_transaksi` varchar(15) NOT NULL,
  `kode_pelanggan` varchar(15) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_produk` varchar(15) NOT NULL,
  `nama_produk` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_b`
--

INSERT INTO `tabel_b` (`id_transaksi`, `kode_transaksi`, `kode_pelanggan`, `no_urut`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(9, 'tr-004', 'polibest03', 1, 'prod-10', 'Sticky Note 500 Sheets', 5, 55000),
(10, 'tr-004', 'polibest03', 2, 'prod-04', 'Flashdisk 32 GB', 4, 40000),
(11, 'tr-005', 'polibest05', 1, 'prod-09', 'Buku Planner Agenda', 3, 92000),
(12, 'tr-005', 'polibest05', 2, 'prod-01', 'Kotak Pensil', 1, 62500),
(13, 'tr-005', 'polibest05', 3, 'prod-04', 'Flashdisk 32 GB', 2, 40000),
(14, 'tr-006', 'polibest02', 1, 'prod-05', 'Gift Voucher 250rb', 4, 250000),
(15, 'tr-006', 'polibest02', 2, 'prod-08', 'Gantungan Kunci', 2, 15800);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_b`
--
ALTER TABLE `tabel_b`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_b`
--
ALTER TABLE `tabel_b`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
