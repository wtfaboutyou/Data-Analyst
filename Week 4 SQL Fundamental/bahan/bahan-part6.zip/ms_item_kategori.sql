-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 08:34 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makul_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ms_item_kategori`
--

CREATE TABLE `ms_item_kategori` (
  `nama_item` varchar(30) NOT NULL,
  `kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ms_item_kategori`
--

INSERT INTO `ms_item_kategori` (`nama_item`, `kategori`) VALUES
('bayam', 'sayuran'),
('belimbing', 'buah'),
('duku', 'buah'),
('durian', 'buah'),
('gandum', 'buah'),
('jambu air', 'buah'),
('jamur', 'sayuran'),
('jeruk', 'buah');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ms_item_kategori`
--
ALTER TABLE `ms_item_kategori`
  ADD PRIMARY KEY (`nama_item`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
